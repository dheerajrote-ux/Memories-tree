# MemoryTree Production Checklist

## Google Cloud
- [ ] Create production OAuth client.
- [ ] Configure authorized origins and redirect URIs.
- [ ] Verify Google Photos Picker API availability for the project.
- [ ] Configure the minimum required scopes.
- [ ] Complete OAuth consent-screen verification where required.

## Supabase
- [ ] Create production project.
- [ ] Enable PostGIS.
- [ ] Enable pgvector.
- [ ] Apply all migrations.
- [ ] Verify RLS on every exposed table.
- [ ] Configure Auth providers.
- [ ] Configure production redirect URLs.
- [ ] Configure database backups/PITR according to plan.

## Application
- [ ] Set production environment variables.
- [ ] Configure encryption key for OAuth tokens.
- [ ] Configure AI provider.
- [ ] Configure geocoding/maps provider.
- [ ] Configure background job worker.
- [ ] Configure structured logging and error monitoring.
- [ ] Run unit/integration/e2e tests.
- [ ] Run accessibility audit.
- [ ] Run dependency/security audit.

## Privacy
- [ ] Explicit pair consent.
- [ ] User can revoke shared access.
- [ ] User can disconnect Google Photos.
- [ ] User can delete imported memory metadata.
- [ ] User can delete shared timeline.
- [ ] Do not expose private memories to the other person.
- [ ] Document retention/deletion policy.
