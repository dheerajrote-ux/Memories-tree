'use client'
import { useState } from 'react'
import { ArrowRight, Check, ChevronRight, Heart, MapPin, RefreshCw, ShieldCheck, Sparkles } from 'lucide-react'
import { demoMemories, stateMeta, type Memory } from '@/lib/data'
export function Pill({state}:{state:Memory['state']}){const m=stateMeta[state];return <span className={`pill ${m.className}`}><span>{m.icon}</span>{m.label}</span>}
export function SyncButton(){const[loading,setLoading]=useState(false);const[done,setDone]=useState(false);async function sync(){setLoading(true);try{await fetch('/api/sync',{method:'POST'});await new Promise(r=>setTimeout(r,900));setDone(true)}finally{setLoading(false)}}return <button className="button primary" onClick={sync} disabled={loading}>{loading?<><RefreshCw size={16} className="spin"/>Syncing…</>:done?<><Check size={16}/>Sync queued</>:<><RefreshCw size={16}/>Sync memories</>}</button>}
export function MemoryCard({memory}:{memory:Memory}){return <article className="memory-card"><div className="memory-image" style={{backgroundImage:`url(${memory.image})`}}/><div className="memory-body"><div className="row between"><Pill state={memory.state}/><span className="muted small">{memory.time}</span></div><h3>{memory.title}</h3><div className="location"><MapPin size={14}/>{memory.location}</div><div className="tags">{memory.tags.map(t=><span key={t}>#{t}</span>)}</div></div></article>}
export function Timeline(){
  const grouped=demoMemories.reduce<Record<string,Memory[]>>((a,m)=>{(a[m.date]??=[]).push(m);return a},{});
  return <div className="timeline">
    {Object.entries(grouped).map(([date,items])=>{
      const state=items[0].state;
      return <div className="timeline-day" key={date}>
        <div className="timeline-date"><span>{new Date(date).toLocaleDateString('en-US',{month:'short',day:'numeric'})}</span><Pill state={state}/></div>
        <div className="timeline-event">
          <div className="event-marker"><Heart size={14}/></div>
          <div className="event-content">
            <div className="row between"><div><div className="eyebrow">{stateMeta[state].label.toUpperCase()}</div><h3>{items[0].title}</h3></div><ChevronRight size={18}/></div>
            <p className="muted">{items[0].location}{items[0].distanceKm?` · ${items[0].distanceKm.toLocaleString()} km apart`:''}</p>
            <div className="mini-grid">{items.map(m=><div key={m.id} className="mini-photo" style={{backgroundImage:`url(${m.image})`}}/>)}</div>
          </div>
        </div>
      </div>;
    })}
  </div>;
}
export function StoryCard(){return <div className="story-card"><div className="story-icon"><Sparkles size={19}/></div><div><div className="eyebrow">MEMORY DETECTIVE</div><h3>March was a month of movement.</h3><p>One of you began the month in Dubai while the other stayed in Pune. By the third week, your paths came together in Goa.</p></div><ArrowRight size={20}/></div>}
export function PrivacyCard(){return <div className="privacy-card"><ShieldCheck size={22}/><div><strong>Your memories stay yours.</strong><p>MemoryTree only creates a shared story from memories both people explicitly choose to share.</p></div></div>}
