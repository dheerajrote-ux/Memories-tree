# MemoryTree production milestone

## Memory Sync Engine
- Added normalized memory model and pairwise timeline classifier.
- Added geospatial/time-based Together, Nearby, Apart and Unknown classification.
- Added authenticated persistence endpoint with pair membership and dual-consent checks.
- Added sync job lifecycle and progress tracking.
- Added deterministic demo sync endpoint.
- Added timeline, memories, map and insights application surfaces.
- Added production migration for sync jobs, source metadata and consent-gated shared reads.

## Security notes
- Service-role Supabase access is server-only.
- Google refresh/access tokens remain encrypted server-side.
- Shared timeline/event reads require both parties to consent.
- The Picker model is explicit-selection based; MemoryTree does not assume unrestricted Google Photos history access.
