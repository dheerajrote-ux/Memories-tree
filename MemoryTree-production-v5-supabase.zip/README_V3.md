# MemoryTree Production v3

This release adds the Memory Intelligence layer on top of the production foundation.

## New capabilities

- Evidence-based event clustering
- Shared event generation for two people
- Story generation constrained to supplied evidence
- `memory_events` and `memory_stories` persistence schema
- pgvector extension enabled for future semantic memory search
- RLS policies for pair-scoped intelligence data

## API

POST `/api/intelligence/events`

Body:
```json
{"personA": [], "personB": []}
```

POST `/api/intelligence/story`

Body:
```json
{"personA": [], "personB": [], "timeline": []}
```

## AI boundary

The current event intelligence is deterministic and evidence-based. It intentionally does not fabricate events or emotions. A production LLM provider can be plugged into `lib/event-intelligence.ts` later for event naming/story refinement, while the factual event graph remains grounded in stored evidence.

## Database

Apply `supabase/migrations/003_memory_intelligence.sql` after migrations 001 and 002.

Supabase supports PostGIS for geospatial data and pgvector for embeddings; RLS should remain enabled on all exposed tables.
