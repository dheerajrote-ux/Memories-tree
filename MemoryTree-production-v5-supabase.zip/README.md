# MemoryTree Production v3

This release adds the Memory Intelligence layer on top of the production foundation.

## New capabilities

- Evidence-based event clustering
- Shared event generation for two people
- Story generation constrained to supplied evidence
- `memory_events` and `memory_stories` persistence schema
- pgvector extension enabled for future semantic memory search
- RLS policies for pair-scoped intelligence data

## API

POST `/api/intelligence/events`

Body:
```json
{"personA": [], "personB": []}
```

POST `/api/intelligence/story`

Body:
```json
{"personA": [], "personB": [], "timeline": []}
```

## AI boundary

The current event intelligence is deterministic and evidence-based. It intentionally does not fabricate events or emotions. A production LLM provider can be plugged into `lib/event-intelligence.ts` later for event naming/story refinement, while the factual event graph remains grounded in stored evidence.

## Database

Apply `supabase/migrations/003_memory_intelligence.sql` after migrations 001 and 002.

Supabase supports PostGIS for geospatial data and pgvector for embeddings; RLS should remain enabled on all exposed tables.

## Production v4 — Memory Intelligence

This release adds the evidence-grounded **While You Were Away** experience.

### New routes

- `/while-away`
- `POST /api/intelligence/while-away`
- `GET /api/demo/while-away`

### Production principles

- Never infer a fact without evidence.
- Keep source memories private; expose only derived shared intelligence after pair consent.
- Treat geospatial/time matching as inference with confidence.
- Generate AI prose only from structured, evidence-backed event records.
- Keep embeddings server-side and protect them with RLS.

### Google Photos

The live Google Photos Picker integration must be configured with the application's Google Cloud OAuth credentials and the current Picker API authorization model. Do not assume unrestricted access to a user's historical library.

### Supabase

Enable the required `postgis` and `vector` extensions in the production project. Keep service-role credentials server-side. Enable RLS on every exposed table.

## Supabase project configuration

The application now uses the current Supabase SSR pattern with:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
- `utils/supabase/server.ts`
- `utils/supabase/client.ts`
- `utils/supabase/middleware.ts`

A local `.env.local` is included for the supplied Supabase project URL and publishable key. Do not commit `.env.local`; production secrets belong in the hosting provider's secret/environment configuration.
