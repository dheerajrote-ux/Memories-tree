-- MemoryTree production memory graph.
-- Keep private source memories separate from derived shared intelligence.

create table if not exists public.memory_event_evidence (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.memory_events(id) on delete cascade,
  memory_id uuid not null references public.memories(id) on delete cascade,
  role text not null default 'supporting',
  confidence numeric(5,4) not null default 1.0,
  created_at timestamptz not null default now()
);

create index if not exists memory_event_evidence_event_idx
  on public.memory_event_evidence(event_id);

create index if not exists memory_event_evidence_memory_idx
  on public.memory_event_evidence(memory_id);

alter table public.memory_event_evidence enable row level security;

-- Access is intentionally pair-scoped through the event.
create policy "pair members can read event evidence"
  on public.memory_event_evidence for select
  to authenticated
  using (
    exists (
      select 1
      from public.memory_events e
      join public.memory_pairs p on p.id = e.memory_pair_id
      where e.id = memory_event_evidence.event_id
        and (select auth.uid()) in (p.user_1_id, p.user_2_id)
    )
  );

-- Vector search is prepared for semantic memory retrieval.
create table if not exists public.memory_embeddings (
  id uuid primary key default gen_random_uuid(),
  memory_id uuid not null references public.memories(id) on delete cascade,
  embedding vector(384),
  model text,
  created_at timestamptz not null default now(),
  unique(memory_id)
);

alter table public.memory_embeddings enable row level security;

create policy "users can read their own memory embeddings"
  on public.memory_embeddings for select
  to authenticated
  using (
    exists (
      select 1
      from public.memories m
      where m.id = memory_embeddings.memory_id
        and m.user_id = (select auth.uid())
    )
  );

-- Do not grant client inserts. Embeddings should be generated server-side.
