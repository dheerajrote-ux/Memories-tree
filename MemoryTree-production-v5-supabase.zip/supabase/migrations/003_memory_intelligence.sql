create extension if not exists vector;

create table if not exists public.memory_events (
  id uuid primary key default gen_random_uuid(),
  memory_pair_id uuid not null references public.memory_pairs(id) on delete cascade,
  owner_user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  category text not null check (category in ('travel','celebration','dining','family','work','everyday','unknown')),
  start_at timestamptz not null,
  end_at timestamptz not null,
  location_name text,
  memory_ids text[] not null default '{}',
  confidence numeric not null default 0.72 check (confidence >= 0 and confidence <= 1),
  created_at timestamptz not null default now()
);

create index if not exists memory_events_pair_start_idx on public.memory_events(memory_pair_id,start_at desc);
create index if not exists memory_events_owner_idx on public.memory_events(owner_user_id);

alter table public.memory_events enable row level security;

create policy "pair members can view memory events" on public.memory_events
for select to authenticated
using (exists (select 1 from public.memory_pairs p where p.id=memory_pair_id and (p.user_1_id=(select auth.uid()) or p.user_2_id=(select auth.uid()))));

create policy "event owner can insert memory events" on public.memory_events
for insert to authenticated
with check (owner_user_id=(select auth.uid()) and exists (select 1 from public.memory_pairs p where p.id=memory_pair_id and (p.user_1_id=(select auth.uid()) or p.user_2_id=(select auth.uid()))));

create table if not exists public.memory_stories (
  id uuid primary key default gen_random_uuid(),
  memory_pair_id uuid not null references public.memory_pairs(id) on delete cascade,
  period_start date,
  period_end date,
  story text not null,
  evidence jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.memory_stories enable row level security;
create policy "pair members can view memory stories" on public.memory_stories
for select to authenticated
using (exists (select 1 from public.memory_pairs p where p.id=memory_pair_id and (p.user_1_id=(select auth.uid()) or p.user_2_id=(select auth.uid()))));

create index if not exists memory_stories_pair_idx on public.memory_stories(memory_pair_id,created_at desc);
