-- MemoryTree production sync engine support.
alter table public.memories add column if not exists source text not null default 'google_photos_picker';
alter table public.memories add column if not exists source_url text;
alter table public.memories add column if not exists timezone text;
alter table public.memories add column if not exists sync_batch_id uuid;
create index if not exists memories_sync_batch_idx on public.memories(sync_batch_id);
create table if not exists public.sync_jobs(
 id uuid primary key default gen_random_uuid(),
 memory_pair_id uuid references public.memory_pairs(id) on delete cascade,
 requested_by uuid not null references public.profiles(id) on delete cascade,
 status text not null default 'queued' check(status in('queued','running','completed','failed','cancelled')),
 progress integer not null default 0 check(progress between 0 and 100),
 stage text not null default 'queued',
 error_message text,
 started_at timestamptz,
 completed_at timestamptz,
 created_at timestamptz not null default now()
);
create index if not exists sync_jobs_pair_idx on public.sync_jobs(memory_pair_id,created_at desc);
alter table public.sync_jobs enable row level security;
create policy "sync jobs members" on public.sync_jobs for select using(requested_by=auth.uid() or exists(select 1 from public.memory_pairs p where p.id=memory_pair_id and(p.user_1_id=auth.uid() or p.user_2_id=auth.uid())));
create policy "sync jobs own insert" on public.sync_jobs for insert with check(requested_by=auth.uid());

-- Pair consent is explicit. Timeline/event reads should require both parties to have consented.
drop policy if exists "events members" on public.events;
create policy "events members with consent" on public.events for select using(exists(select 1 from public.memory_pairs p where p.id=memory_pair_id and p.consent_user_1=true and p.consent_user_2=true and(p.user_1_id=auth.uid() or p.user_2_id=auth.uid())));
drop policy if exists "timeline members" on public.shared_timeline;
create policy "timeline members with consent" on public.shared_timeline for select using(exists(select 1 from public.memory_pairs p where p.id=memory_pair_id and p.consent_user_1=true and p.consent_user_2=true and(p.user_1_id=auth.uid() or p.user_2_id=auth.uid())));
create index if not exists memories_user_location_idx on public.memories using gist(location) where location is not null;
