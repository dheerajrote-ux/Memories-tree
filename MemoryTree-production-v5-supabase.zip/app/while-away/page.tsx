import { demoWhileAway } from "@/lib/intelligence/demo-data";
import { buildWhileAwaySegments } from "@/lib/intelligence/while-away";

export default function WhileAwayPage() {
  const segments = buildWhileAwaySegments(
    demoWhileAway.person1Events,
    demoWhileAway.person2Events
  );

  return (
    <main className="min-h-screen bg-[#faf9f7] px-6 py-12 text-neutral-950">
      <div className="mx-auto max-w-6xl">
        <p className="text-sm font-medium tracking-[0.18em] uppercase text-neutral-500">
          MemoryTree
        </p>
        <h1 className="mt-4 text-5xl font-semibold tracking-tight">
          While You Were Away
        </h1>
        <p className="mt-4 max-w-2xl text-lg text-neutral-600">
          See the memories each of you created during the moments your lives
          took different paths — and the moments they came back together.
        </p>

        <section className="mt-10 grid gap-5 md:grid-cols-3">
          <Stat label="Apart periods" value={String(segments.filter(s => s.status === "APART").length)} />
          <Stat label="Nearby periods" value={String(segments.filter(s => s.status === "NEARBY").length)} />
          <Stat label="Shared story" value="2 events" />
        </section>

        <section className="mt-12 space-y-5">
          {segments.map((segment, index) => {
            const a = segment.person1Events[0];
            const b = segment.person2Events[0];

            return (
              <article
                key={`${segment.startAt}-${index}`}
                className="rounded-3xl border border-black/5 bg-white p-6 shadow-sm"
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <span className="rounded-full bg-neutral-100 px-3 py-1 text-sm font-medium">
                    {segment.status === "APART" ? "Apart" : segment.status === "NEARBY" ? "Nearby" : "Unknown"}
                  </span>
                  {segment.distanceKm != null && (
                    <span className="text-sm text-neutral-500">
                      {Math.round(segment.distanceKm).toLocaleString()} km apart
                    </span>
                  )}
                </div>

                <div className="mt-6 grid gap-5 md:grid-cols-2">
                  <MemoryCard person="Dhiraj" event={a} />
                  <MemoryCard person="Shweta" event={b} />
                </div>
              </article>
            );
          })}
        </section>
      </div>
    </main>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-3xl bg-white p-6 shadow-sm border border-black/5">
      <p className="text-sm text-neutral-500">{label}</p>
      <p className="mt-2 text-3xl font-semibold">{value}</p>
    </div>
  );
}

function MemoryCard({
  person,
  event,
}: {
  person: string;
  event: { title: string; locationName?: string | null; memoryCount: number; category: string };
}) {
  return (
    <div className="rounded-2xl bg-neutral-50 p-5">
      <p className="text-sm text-neutral-500">{person}</p>
      <h2 className="mt-2 text-xl font-semibold">{event.title}</h2>
      <p className="mt-1 text-sm text-neutral-600">{event.locationName ?? "Location unknown"}</p>
      <p className="mt-4 text-sm text-neutral-500">
        {event.memoryCount} memories · {event.category}
      </p>
    </div>
  );
}
