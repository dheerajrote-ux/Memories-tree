'use client'
import { useState } from 'react'
import { createBrowserClient } from '@supabase/ssr'

export default function LoginPage() {
  const [error, setError] = useState('')
  const login = async () => {
    const supabase = createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!)
    const { error } = await supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: `${window.location.origin}/auth/callback` } })
    if (error) setError(error.message)
  }
  return <main className="auth-shell"><div className="auth-card"><div className="brand"><div className="brand-mark">M</div><span>MemoryTree</span></div><div className="eyebrow">YOUR MEMORIES, CONNECTED</div><h1 className="serif">Two lives.<br/><em>One timeline.</em></h1><p>Sign in securely with Google to start building your shared memory timeline.</p><button className="button primary full" onClick={login}>Continue with Google</button>{error && <p className="error">{error}</p>}<small>MemoryTree only requests access needed for the features you explicitly enable.</small></div></main>
}
