import { NextResponse } from 'next/server'
import { requireUser } from '@/lib/auth-server'
import { getSupabaseAdmin } from '@/lib/supabase-admin'
import { buildSharedTimeline, type SourceMemory } from '@/lib/sync-engine'

export async function POST(req: Request) {
  let user
  try { user = await requireUser() } catch { return NextResponse.json({ error: 'Unauthorized' }, { status: 401 }) }
  const body = await req.json() as { pairId?: string; personA?: SourceMemory[]; personB?: SourceMemory[] }
  if (!body.pairId || !Array.isArray(body.personA) || !Array.isArray(body.personB)) return NextResponse.json({ error: 'pairId, personA and personB are required' }, { status: 400 })
  const admin = getSupabaseAdmin()
  const { data: pair, error: pairError } = await admin.from('memory_pairs').select('*').eq('id', body.pairId).maybeSingle()
  if (pairError) return NextResponse.json({ error: pairError.message }, { status: 500 })
  if (!pair || (pair.user_1_id !== user.id && pair.user_2_id !== user.id)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  if (!pair.consent_user_1 || !pair.consent_user_2) return NextResponse.json({ error: 'Both people must consent before a shared timeline can be generated.' }, { status: 409 })
  const job = await admin.from('sync_jobs').insert({ memory_pair_id: body.pairId, requested_by: user.id, status: 'running', progress: 10, stage: 'normalizing' }).select('id').single()
  if (job.error) return NextResponse.json({ error: job.error.message }, { status: 500 })
  try {
    await admin.from('sync_jobs').update({ progress: 35, stage: 'ingesting' }).eq('id', job.data.id)
    const all = [...body.personA, ...body.personB]
    const rows = all.map(m => ({ user_id: m.userId, external_id: m.id, media_type: 'PHOTO', filename: m.title, captured_at: m.capturedAt, location: m.lat != null && m.lng != null ? `POINT(${m.lng} ${m.lat})` : null, location_name: m.locationName, location_accuracy_meters: m.accuracyMeters, metadata: m.metadata ?? {}, source: 'google_photos_picker' }))
    const { error: memoriesError } = await admin.from('memories').upsert(rows, { onConflict: 'user_id,external_id' })
    if (memoriesError) throw memoriesError
    await admin.from('sync_jobs').update({ progress: 70, stage: 'matching' }).eq('id', job.data.id)
    const timeline = buildSharedTimeline(body.personA, body.personB)
    const timelineRows = timeline.map(t => ({ memory_pair_id: body.pairId, timeline_date: t.date, relationship_state: t.state, distance_km: t.distanceKm ?? null, confidence: t.confidence, evidence: t.evidence }))
    const { error: timelineError } = await admin.from('shared_timeline').upsert(timelineRows, { onConflict: 'memory_pair_id,timeline_date' })
    if (timelineError) throw timelineError
    await admin.from('sync_jobs').update({ progress: 100, stage: 'completed', status: 'completed', completed_at: new Date().toISOString() }).eq('id', job.data.id)
    return NextResponse.json({ jobId: job.data.id, timeline })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Sync failed'
    await admin.from('sync_jobs').update({ status: 'failed', stage: 'failed', error_message: message }).eq('id', job.data.id)
    return NextResponse.json({ error: message, jobId: job.data.id }, { status: 500 })
  }
}
