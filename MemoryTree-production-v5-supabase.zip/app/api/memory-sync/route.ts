import { NextResponse } from 'next/server'
import { requireUser } from '@/lib/auth-server'
import { buildSharedTimeline, type SourceMemory } from '@/lib/sync-engine'

export async function POST(req: Request) {
  let user
  try { user = await requireUser() } catch { return NextResponse.json({ error: 'Unauthorized' }, { status: 401 }) }
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const body = await req.json() as { personA?: SourceMemory[]; personB?: SourceMemory[] }
  if (!Array.isArray(body.personA) || !Array.isArray(body.personB)) return NextResponse.json({ error: 'personA and personB arrays are required' }, { status: 400 })
  const timeline = buildSharedTimeline(body.personA, body.personB)
  return NextResponse.json({ timeline, generatedAt: new Date().toISOString() })
}
