import { NextResponse } from 'next/server'
import crypto from 'node:crypto'
import { getGoogleAuthorizationUrl } from '@/lib/integrations/google-photos'

export async function GET(request: Request) {
  const state = crypto.randomBytes(32).toString('base64url')
  const response = NextResponse.redirect(getGoogleAuthorizationUrl(state))
  response.cookies.set('memorytree_google_oauth_state', state, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', maxAge: 600, path: '/' })
  return response
}
