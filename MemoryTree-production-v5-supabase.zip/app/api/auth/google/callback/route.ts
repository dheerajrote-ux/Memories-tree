import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { getServerSupabase } from '@/lib/auth-server'
import { exchangeCodeForTokens } from '@/lib/integrations/google-photos'
import { saveGoogleTokens } from '@/lib/google-token'

export async function GET(request: Request) {
  const url = new URL(request.url)
  const code = url.searchParams.get('code')
  const state = url.searchParams.get('state')
  const cookieStore = await cookies()
  const expected = cookieStore.get('memorytree_google_oauth_state')?.value
  if (!code || !state || !expected || state !== expected) return NextResponse.json({ error: 'Invalid OAuth state.' }, { status: 400 })
  const supabase = await getServerSupabase()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.redirect(new URL('/login?error=sign-in-required', request.url))
  const tokens = await exchangeCodeForTokens(code)
  await saveGoogleTokens(user.id, tokens)
  const response = NextResponse.redirect(new URL('/settings?google=connected', request.url))
  response.cookies.delete('memorytree_google_oauth_state')
  return response
}
