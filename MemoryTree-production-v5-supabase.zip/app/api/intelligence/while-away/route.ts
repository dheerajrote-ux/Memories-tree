import { NextRequest, NextResponse } from "next/server";
import {
  buildWhileAwaySegments,
  buildWhileAwaySummary,
  type MemoryEvent,
} from "@/lib/intelligence/while-away";

/**
 * POST /api/intelligence/while-away
 *
 * Production boundary for the "While You Were Away" experience.
 * The caller supplies already-authorized event records. In production,
 * replace the demo payload with a server-side Supabase query protected by RLS
 * and pair membership checks.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const person1Name = String(body.person1Name ?? "Person 1");
    const person2Name = String(body.person2Name ?? "Person 2");
    const person1Events = (body.person1Events ?? []) as MemoryEvent[];
    const person2Events = (body.person2Events ?? []) as MemoryEvent[];

    if (!Array.isArray(person1Events) || !Array.isArray(person2Events)) {
      return NextResponse.json(
        { error: "person1Events and person2Events must be arrays" },
        { status: 400 }
      );
    }

    const segments = buildWhileAwaySegments(person1Events, person2Events);
    return NextResponse.json(
      buildWhileAwaySummary(person1Name, person2Name, segments)
    );
  } catch {
    return NextResponse.json(
      { error: "Unable to build the while-away story" },
      { status: 400 }
    );
  }
}
