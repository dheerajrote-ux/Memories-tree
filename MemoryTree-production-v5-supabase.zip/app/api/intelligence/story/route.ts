import { NextResponse } from 'next/server'
import { requireUser } from '@/lib/auth-server'
import { generateStory } from '@/lib/event-intelligence'
import type { SourceMemory, TimelineRecord } from '@/lib/sync-engine'

export async function POST(req: Request) {
  try { await requireUser() } catch { return NextResponse.json({error:'Unauthorized'},{status:401}) }
  const body = await req.json() as { personA?: SourceMemory[]; personB?: SourceMemory[]; timeline?: TimelineRecord[] }
  if (!Array.isArray(body.personA) || !Array.isArray(body.personB) || !Array.isArray(body.timeline)) return NextResponse.json({error:'personA, personB and timeline are required'},{status:400})
  return NextResponse.json({ story:generateStory(body.personA,body.personB,body.timeline), generatedAt:new Date().toISOString() })
}
