import { NextResponse } from 'next/server'
import { requireUser } from '@/lib/auth-server'
import { clusterEvents, buildSharedEvents } from '@/lib/event-intelligence'
import type { SourceMemory } from '@/lib/sync-engine'

export async function POST(req: Request) {
  try { await requireUser() } catch { return NextResponse.json({error:'Unauthorized'},{status:401}) }
  const body = await req.json() as { personA?: SourceMemory[]; personB?: SourceMemory[] }
  if (!Array.isArray(body.personA)) return NextResponse.json({error:'personA is required'},{status:400})
  const events = Array.isArray(body.personB) ? buildSharedEvents(body.personA,body.personB) : clusterEvents(body.personA)
  return NextResponse.json({ events, generatedAt:new Date().toISOString(), mode:'evidence-based-clustering' })
}
