import{NextResponse}from'next/server';export async function GET(){return NextResponse.json({ok:true,service:'memorytree',timestamp:new Date().toISOString(),environment:process.env.NODE_ENV})}
