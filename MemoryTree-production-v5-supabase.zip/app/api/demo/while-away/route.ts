import { NextResponse } from "next/server";
import { demoWhileAway } from "@/lib/intelligence/demo-data";
import { buildWhileAwaySummary, buildWhileAwaySegments } from "@/lib/intelligence/while-away";

export async function GET() {
  const segments = buildWhileAwaySegments(
    demoWhileAway.person1Events,
    demoWhileAway.person2Events
  );

  return NextResponse.json(
    buildWhileAwaySummary(demoWhileAway.person1Name, demoWhileAway.person2Name, segments)
  );
}
