import { NextResponse } from 'next/server'
import { buildSharedTimeline, type SourceMemory } from '@/lib/sync-engine'

const demoA: SourceMemory[] = [
 {id:'a1',userId:'demo-a',capturedAt:'2025-03-10T10:30:00Z',lat:25.1972,lng:55.2744,locationName:'Dubai, UAE',title:'Burj Khalifa'},
 {id:'a2',userId:'demo-a',capturedAt:'2025-03-18T18:30:00Z',lat:19.076,lng:72.8777,locationName:'Mumbai, India',title:'Mumbai arrival'},
 {id:'a3',userId:'demo-a',capturedAt:'2025-03-20T12:15:00Z',lat:15.4909,lng:73.8278,locationName:'Goa, India',title:'Beach afternoon'},
]
const demoB: SourceMemory[] = [
 {id:'b1',userId:'demo-b',capturedAt:'2025-03-10T19:00:00Z',lat:18.5204,lng:73.8567,locationName:'Pune, India',title:'Birthday party'},
 {id:'b2',userId:'demo-b',capturedAt:'2025-03-18T19:10:00Z',lat:19.1136,lng:72.8697,locationName:'Bandra, Mumbai',title:'Dinner in Mumbai'},
 {id:'b3',userId:'demo-b',capturedAt:'2025-03-20T12:40:00Z',lat:15.4909,lng:73.8278,locationName:'Goa, India',title:'Beach afternoon'},
]

export async function POST() {
  return NextResponse.json({ timeline: buildSharedTimeline(demoA, demoB), source: 'demo' })
}
