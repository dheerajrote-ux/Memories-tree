import { NextResponse } from 'next/server'
import { requireUser } from '@/lib/auth-server'
import { getGoogleAccessToken } from '@/lib/google-token'
import { listPickedMedia } from '@/lib/integrations/google-photos'

export async function GET(request: Request) {
  try { const user = await requireUser(); const url = new URL(request.url); const sessionId = url.searchParams.get('sessionId'); if (!sessionId) return NextResponse.json({ error: 'sessionId is required' }, { status: 400 }); return NextResponse.json(await listPickedMedia(await getGoogleAccessToken(user.id), sessionId, url.searchParams.get('pageToken') ?? undefined)) }
  catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to retrieve selected media.' }, { status: 400 }) }
}
