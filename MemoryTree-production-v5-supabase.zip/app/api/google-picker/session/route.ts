import { NextResponse } from 'next/server'
import { requireUser } from '@/lib/auth-server'
import { createPickerSession } from '@/lib/integrations/google-photos'
import { getGoogleAccessToken } from '@/lib/google-token'

export async function POST() {
  try {
    const user = await requireUser()
    const token = await getGoogleAccessToken(user.id)
    const session = await createPickerSession(token)
    return NextResponse.json(session)
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to create picker session.' }, { status: 401 })
  }
}
