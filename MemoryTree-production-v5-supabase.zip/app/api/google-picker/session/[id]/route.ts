import { NextResponse } from 'next/server'
import { requireUser } from '@/lib/auth-server'
import { getGoogleAccessToken } from '@/lib/google-token'
import { getPickerSession } from '@/lib/integrations/google-photos'

export async function GET(_: Request, context: { params: Promise<{ id: string }> }) {
  try { const user = await requireUser(); const { id } = await context.params; return NextResponse.json(await getPickerSession(await getGoogleAccessToken(user.id), id)) }
  catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : 'Unable to read picker session.' }, { status: 400 }) }
}
