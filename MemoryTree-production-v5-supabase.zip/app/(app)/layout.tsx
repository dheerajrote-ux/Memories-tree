import {Nav} from '@/components/nav'
export default function AppLayout({children}:{children:React.ReactNode}){return <div className="app-shell"><Nav/><main className="main">{children}</main></div>}
