import { classifyRelationship, haversineKm, type MemoryPoint } from './memory-engine'

export type SourceMemory = {
  id: string
  userId: string
  capturedAt: string
  lat?: number | null
  lng?: number | null
  accuracyMeters?: number | null
  title?: string | null
  locationName?: string | null
  metadata?: Record<string, unknown>
}

export type TimelineRecord = {
  date: string
  state: 'TOGETHER' | 'NEARBY' | 'APART' | 'UNKNOWN'
  distanceKm?: number
  confidence: number
  evidence: { memoryA: string; memoryB: string; timeDifferenceMinutes: number; distanceKm?: number }
}

const minutesBetween = (a: string, b: string) => Math.abs(new Date(a).getTime() - new Date(b).getTime()) / 60000

function dayKey(timestamp: string) {
  return timestamp.slice(0, 10)
}

export function buildSharedTimeline(personA: SourceMemory[], personB: SourceMemory[]): TimelineRecord[] {
  const byDay = new Map<string, { a: SourceMemory[]; b: SourceMemory[] }>()
  for (const m of personA) byDay.set(dayKey(m.capturedAt), { a: [...(byDay.get(dayKey(m.capturedAt))?.a ?? []), m], b: byDay.get(dayKey(m.capturedAt))?.b ?? [] })
  for (const m of personB) byDay.set(dayKey(m.capturedAt), { a: byDay.get(dayKey(m.capturedAt))?.a ?? [], b: [...(byDay.get(dayKey(m.capturedAt))?.b ?? []), m] })

  const results: TimelineRecord[] = []
  for (const [date, group] of [...byDay.entries()].sort()) {
    if (!group.a.length || !group.b.length) {
      results.push({ date, state: 'UNKNOWN', confidence: 0.35, evidence: { memoryA: group.a[0]?.id ?? '', memoryB: group.b[0]?.id ?? '', timeDifferenceMinutes: 0 } })
      continue
    }

    let best: TimelineRecord | undefined
    for (const a of group.a) for (const b of group.b) {
      const delta = minutesBetween(a.capturedAt, b.capturedAt)
      let distanceKm: number | undefined
      if (a.lat != null && a.lng != null && b.lat != null && b.lng != null) {
        const pa: MemoryPoint = { lat: a.lat, lng: a.lng, timestamp: a.capturedAt, accuracyMeters: a.accuracyMeters ?? undefined }
        const pb: MemoryPoint = { lat: b.lat, lng: b.lng, timestamp: b.capturedAt, accuracyMeters: b.accuracyMeters ?? undefined }
        distanceKm = haversineKm(pa, pb)
        const classified = classifyRelationship(distanceKm, delta)
        const candidate: TimelineRecord = { date, state: classified.state, confidence: classified.confidence, distanceKm, evidence: { memoryA: a.id, memoryB: b.id, timeDifferenceMinutes: Math.round(delta), distanceKm } }
        if (!best || candidate.confidence > best.confidence) best = candidate
      }
    }

    if (!best) {
      const delta = Math.min(...group.a.flatMap(a => group.b.map(b => minutesBetween(a.capturedAt, b.capturedAt))))
      best = { date, state: 'UNKNOWN', confidence: 0.4, evidence: { memoryA: group.a[0].id, memoryB: group.b[0].id, timeDifferenceMinutes: Math.round(delta) } }
    }
    results.push(best)
  }
  return results
}

export function normalizePickerMemory(input: { id: string; createTime?: string; filename?: string; location?: { latitude?: number; longitude?: number } | null; mimeType?: string }, userId: string): SourceMemory {
  return { id: input.id, userId, capturedAt: input.createTime ?? new Date().toISOString(), lat: input.location?.latitude ?? null, lng: input.location?.longitude ?? null, title: input.filename ?? null, metadata: { mimeType: input.mimeType } }
}
