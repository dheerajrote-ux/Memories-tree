import type { SourceMemory } from './sync-engine'

export type MemoryEvent = {
  id: string
  ownerId: string
  title: string
  category: 'travel'|'celebration'|'dining'|'family'|'work'|'everyday'|'unknown'
  startAt: string
  endAt: string
  locationName?: string | null
  memoryIds: string[]
  confidence: number
}

const HOURS = 60 * 60 * 1000

function distanceKm(a: SourceMemory, b: SourceMemory) {
  if (a.lat == null || a.lng == null || b.lat == null || b.lng == null) return null
  const R = 6371
  const dLat = (b.lat-a.lat)*Math.PI/180
  const dLon = (b.lng-a.lng)*Math.PI/180
  const x = Math.sin(dLat/2)**2 + Math.cos(a.lat*Math.PI/180)*Math.cos(b.lat*Math.PI/180)*Math.sin(dLon/2)**2
  return R*2*Math.atan2(Math.sqrt(x),Math.sqrt(1-x))
}

function categoryFor(m: SourceMemory): MemoryEvent['category'] {
  const text = `${m.title ?? ''} ${m.locationName ?? ''}`.toLowerCase()
  if (/airport|flight|airplane|dubai|singapore|london|paris|trip|travel/.test(text)) return 'travel'
  if (/birthday|wedding|party|celebration|cake|anniversary/.test(text)) return 'celebration'
  if (/restaurant|dinner|lunch|cafe|food|bar/.test(text)) return 'dining'
  if (/office|work|conference|meeting|client/.test(text)) return 'work'
  if (/family|mom|dad|mother|father|son|daughter/.test(text)) return 'family'
  return 'everyday'
}

function titleFor(category: MemoryEvent['category'], location?: string | null) {
  const names = { travel:'Trip', celebration:'Celebration', dining:'Dining', family:'Family time', work:'Work event', everyday:'Memory', unknown:'Memory' }
  return location ? `${location} ${names[category].toLowerCase()}` : names[category]
}

export function clusterEvents(memories: SourceMemory[]): MemoryEvent[] {
  const sorted = [...memories].sort((a,b)=>a.capturedAt.localeCompare(b.capturedAt))
  const events: MemoryEvent[] = []
  for (const memory of sorted) {
    const last = events.at(-1)
    const lastMemory = last ? sorted.find(m=>m.id===last.memoryIds.at(-1)) : undefined
    const samePlace = lastMemory ? (distanceKm(memory,lastMemory) ?? 999) <= 5 : false
    const closeInTime = lastMemory ? new Date(memory.capturedAt).getTime()-new Date(lastMemory.capturedAt).getTime() <= 4*HOURS : false
    if (last && samePlace && closeInTime) {
      last.memoryIds.push(memory.id)
      last.endAt = memory.capturedAt
      last.confidence = Math.min(0.99, last.confidence + 0.01)
    } else {
      const category = categoryFor(memory)
      events.push({ id:`evt_${memory.id}`, ownerId:memory.userId, title:titleFor(category,memory.locationName), category, startAt:memory.capturedAt, endAt:memory.capturedAt, locationName:memory.locationName, memoryIds:[memory.id], confidence:0.72 })
    }
  }
  return events
}

export function buildSharedEvents(a: SourceMemory[], b: SourceMemory[]) {
  return [...clusterEvents(a), ...clusterEvents(b)]
}

export function generateStory(a: SourceMemory[], b: SourceMemory[], timeline: {date:string,state:string,distanceKm?:number}[]) {
  const together = timeline.filter(x=>x.state==='TOGETHER').length
  const apart = timeline.filter(x=>x.state==='APART').length
  const nearby = timeline.filter(x=>x.state==='NEARBY').length
  const locations = [...a,...b].map(m=>m.locationName).filter(Boolean) as string[]
  const uniqueLocations = [...new Set(locations)].slice(0,5)
  const parts = []
  if (together) parts.push(`${together} day${together===1?'':'s'} of shared memories`)
  if (apart) parts.push(`${apart} day${apart===1?'':'s'} where your memories place you apart`)
  if (nearby) parts.push(`${nearby} nearby day${nearby===1?'':'s'}`)
  const placeText = uniqueLocations.length ? ` across ${uniqueLocations.join(', ')}` : ''
  return `Your memory graph contains ${parts.join(', ')}${placeText}. This story is based only on the memories and metadata you selected; it does not infer feelings or events that are not supported by evidence.`
}
