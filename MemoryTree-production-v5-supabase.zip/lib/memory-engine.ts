import type { MemoryState } from './data'

export type MemoryPoint = {
  lat: number
  lng: number
  timestamp: string
  accuracyMeters?: number
}

export function haversineKm(a: MemoryPoint, b: MemoryPoint) {
  const R = 6371
  const dLat = (b.lat - a.lat) * Math.PI / 180
  const dLon = (b.lng - a.lng) * Math.PI / 180
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180) * Math.sin(dLon / 2) ** 2
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x))
}

export function classifyRelationship(distanceKm: number, timeDifferenceMinutes: number): { state: MemoryState; confidence: number } {
  if (distanceKm <= 0.5 && timeDifferenceMinutes <= 120) return { state:'TOGETHER', confidence:0.92 }
  if (distanceKm <= 10 && timeDifferenceMinutes <= 180) return { state:'NEARBY', confidence:0.84 }
  if (distanceKm > 50) return { state:'APART', confidence:0.94 }
  return { state:'UNKNOWN', confidence:0.45 }
}
