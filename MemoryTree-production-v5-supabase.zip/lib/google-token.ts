import { decryptSecret, encryptSecret } from './crypto'
import { getSupabaseAdmin } from './supabase-admin'

const TOKEN_URL = 'https://oauth2.googleapis.com/token'

export async function saveGoogleTokens(userId: string, tokens: { access_token: string; expires_in: number; refresh_token?: string; scope?: string }) {
  const supabase = getSupabaseAdmin()
  const existing = await supabase.from('google_connections').select('encrypted_refresh_token').eq('user_id', userId).eq('provider', 'google_photos').maybeSingle()
  if (existing.error) throw existing.error
  const refreshToken = tokens.refresh_token ? encryptSecret(tokens.refresh_token) : existing.data?.encrypted_refresh_token
  if (!refreshToken) throw new Error('Google did not return a refresh token. Re-authorize with consent.')
  const expiresAt = new Date(Date.now() + Math.max(tokens.expires_in - 60, 60) * 1000).toISOString()
  const { error } = await supabase.from('google_connections').upsert({
    user_id: userId,
    provider: 'google_photos',
    encrypted_refresh_token: refreshToken,
    encrypted_access_token: encryptSecret(tokens.access_token),
    access_token_expires_at: expiresAt,
    scopes: tokens.scope?.split(' ') ?? [],
    status: 'active',
    updated_at: new Date().toISOString(),
  }, { onConflict: 'user_id,provider' })
  if (error) throw error
}

export async function getGoogleAccessToken(userId: string) {
  const supabase = getSupabaseAdmin()
  const { data, error } = await supabase.from('google_connections').select('*').eq('user_id', userId).eq('provider', 'google_photos').maybeSingle()
  if (error) throw error
  if (!data) throw new Error('Google Photos is not connected.')
  if (data.encrypted_access_token && data.access_token_expires_at && new Date(data.access_token_expires_at).getTime() > Date.now() + 30_000) {
    return decryptSecret(data.encrypted_access_token)
  }
  const refreshToken = decryptSecret(data.encrypted_refresh_token)
  const body = new URLSearchParams({ client_id: process.env.GOOGLE_CLIENT_ID ?? '', client_secret: process.env.GOOGLE_CLIENT_SECRET ?? '', refresh_token: refreshToken, grant_type: 'refresh_token' })
  const response = await fetch(TOKEN_URL, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body })
  if (!response.ok) throw new Error(`Google token refresh failed: ${await response.text()}`)
  const refreshed = await response.json() as { access_token: string; expires_in: number; scope?: string }
  await saveGoogleTokens(userId, refreshed)
  return refreshed.access_token
}
