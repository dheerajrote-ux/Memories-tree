export type GooglePhotoItem = {
  id: string
  createTime: string
  type: 'PHOTO' | 'VIDEO' | string
  mediaFile?: {
    baseUrl?: string
    mimeType?: string
    filename?: string
    mediaFileMetadata?: {
      width?: string
      height?: string
      photo?: { cameraMake?: string; cameraModel?: string; focalLength?: number }
    }
  }
}

const PICKER_SCOPE='https://www.googleapis.com/auth/photospicker.mediaitems.readonly'
const PICKER_BASE='https://photospicker.googleapis.com/v1'

export class GooglePhotosError extends Error {
  constructor(message:string, public status?:number){super(message)}
}

export function googlePhotosScope(){return PICKER_SCOPE}

export async function createPickerSession(accessToken:string){
  const response=await fetch(`${PICKER_BASE}/sessions`,{method:'POST',headers:{Authorization:`Bearer ${accessToken}`,'Content-Type':'application/json'},body:JSON.stringify({})})
  if(!response.ok) throw new GooglePhotosError(await response.text(),response.status)
  return response.json() as Promise<{id:string;pickerUri:string;pollingConfig?:{pollInterval:string;timeoutIn:string}}>
}

export async function getPickerSession(accessToken:string,sessionId:string){
  const response=await fetch(`${PICKER_BASE}/sessions/${encodeURIComponent(sessionId)}`,{headers:{Authorization:`Bearer ${accessToken}`}})
  if(!response.ok) throw new GooglePhotosError(await response.text(),response.status)
  return response.json() as Promise<{id:string;pickerUri?:string;mediaItemsSet?:boolean;pollingConfig?:{pollInterval:string;timeoutIn:string}}>
}

export async function listPickedMedia(accessToken:string,sessionId:string,pageToken?:string){
  const url=new URL(`${PICKER_BASE}/mediaItems`);url.searchParams.set('sessionId',sessionId);if(pageToken)url.searchParams.set('pageToken',pageToken)
  const response=await fetch(url,{headers:{Authorization:`Bearer ${accessToken}`}})
  if(!response.ok) throw new GooglePhotosError(await response.text(),response.status)
  return response.json() as Promise<{mediaItems:GooglePhotoItem[];nextPageToken?:string}>
}

export async function deletePickerSession(accessToken:string,sessionId:string){
  const response=await fetch(`${PICKER_BASE}/sessions/${encodeURIComponent(sessionId)}`,{method:'DELETE',headers:{Authorization:`Bearer ${accessToken}`}})
  if(!response.ok && response.status!==404) throw new GooglePhotosError(await response.text(),response.status)
}

export function getGoogleAuthorizationUrl(state:string){
  const clientId=process.env.GOOGLE_CLIENT_ID
  const redirectUri=process.env.GOOGLE_REDIRECT_URI
  if(!clientId||!redirectUri) throw new GooglePhotosError('Google OAuth environment variables are not configured.')
  const url=new URL('https://accounts.google.com/o/oauth2/v2/auth')
  url.searchParams.set('client_id',clientId);url.searchParams.set('redirect_uri',redirectUri);url.searchParams.set('response_type','code');url.searchParams.set('scope',`openid email profile ${PICKER_SCOPE}`);url.searchParams.set('access_type','offline');url.searchParams.set('prompt','consent');url.searchParams.set('state',state)
  return url.toString()
}

export async function exchangeCodeForTokens(code:string){
  const clientId=process.env.GOOGLE_CLIENT_ID,clientSecret=process.env.GOOGLE_CLIENT_SECRET,redirectUri=process.env.GOOGLE_REDIRECT_URI
  if(!clientId||!clientSecret||!redirectUri) throw new GooglePhotosError('Google OAuth environment variables are not configured.')
  const body=new URLSearchParams({code,client_id:clientId,client_secret:clientSecret,redirect_uri:redirectUri,grant_type:'authorization_code'})
  const response=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body})
  if(!response.ok) throw new GooglePhotosError(await response.text(),response.status)
  return response.json() as Promise<{access_token:string;expires_in:number;refresh_token?:string;scope:string;token_type:string;id_token?:string}>
}
