export type MemoryState = 'TOGETHER' | 'NEARBY' | 'APART' | 'UNKNOWN'

export type Memory = {
  id: string
  person: 'Dhiraj' | 'Shweta'
  date: string
  time: string
  title: string
  location: string
  city: string
  country: string
  state: MemoryState
  confidence: number
  distanceKm?: number
  image: string
  tags: string[]
}

export const demoMemories: Memory[] = [
  { id:'m1', person:'Dhiraj', date:'2025-03-10', time:'10:30', title:'Burj Khalifa', location:'Dubai, UAE', city:'Dubai', country:'UAE', state:'APART', confidence:0.98, distanceKm:1967, image:'https://images.unsplash.com/photo-1518684079-3c830dcef090?auto=format&fit=crop&w=900&q=80', tags:['travel','landmark'] },
  { id:'m2', person:'Shweta', date:'2025-03-10', time:'19:00', title:'Birthday party', location:'Pune, India', city:'Pune', country:'India', state:'APART', confidence:0.96, distanceKm:1967, image:'https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=900&q=80', tags:['celebration','friends'] },
  { id:'m3', person:'Dhiraj', date:'2025-03-18', time:'18:30', title:'Mumbai arrival', location:'Mumbai, India', city:'Mumbai', country:'India', state:'NEARBY', confidence:0.91, distanceKm:7, image:'https://images.unsplash.com/photo-1570168007204-dfb528c6958f?auto=format&fit=crop&w=900&q=80', tags:['travel'] },
  { id:'m4', person:'Shweta', date:'2025-03-18', time:'19:10', title:'Dinner in Mumbai', location:'Bandra, Mumbai', city:'Mumbai', country:'India', state:'NEARBY', confidence:0.91, distanceKm:7, image:'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=900&q=80', tags:['dining'] },
  { id:'m5', person:'Dhiraj', date:'2025-03-20', time:'12:15', title:'Beach afternoon', location:'Goa, India', city:'Goa', country:'India', state:'TOGETHER', confidence:0.97, distanceKm:0.3, image:'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=900&q=80', tags:['vacation','beach'] },
  { id:'m6', person:'Shweta', date:'2025-03-20', time:'12:40', title:'Beach afternoon', location:'Goa, India', city:'Goa', country:'India', state:'TOGETHER', confidence:0.97, distanceKm:0.3, image:'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=900&q=80', tags:['vacation','beach'] },
  { id:'m7', person:'Dhiraj', date:'2025-04-02', time:'09:00', title:'Design workshop', location:'Pune, India', city:'Pune', country:'India', state:'TOGETHER', confidence:0.84, distanceKm:0.8, image:'https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=900&q=80', tags:['work'] },
  { id:'m8', person:'Shweta', date:'2025-04-02', time:'18:20', title:'Evening walk', location:'Pune, India', city:'Pune', country:'India', state:'TOGETHER', confidence:0.84, distanceKm:0.8, image:'https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?auto=format&fit=crop&w=900&q=80', tags:['everyday'] },
]

export const stateMeta = {
  TOGETHER: { label:'Together', icon:'♥', className:'together' },
  NEARBY: { label:'Nearby', icon:'◌', className:'nearby' },
  APART: { label:'Apart', icon:'↗', className:'apart' },
  UNKNOWN: { label:'Unknown', icon:'?', className:'unknown' },
} as const
