/**
 * Evidence-grounded "While You Were Away" story engine.
 *
 * This module deliberately does not invent events. It receives normalized
 * events from both people and returns a deterministic story model. An LLM
 * can later turn this model into prose, but the model remains the source of truth.
 */

export type MemoryEvent = {
  id: string;
  ownerId: string;
  title: string;
  category: string;
  startAt: string;
  endAt: string;
  locationName?: string | null;
  latitude?: number | null;
  longitude?: number | null;
  memoryCount: number;
  confidence: number;
};

export type AwaySegment = {
  startAt: string;
  endAt: string;
  person1Events: MemoryEvent[];
  person2Events: MemoryEvent[];
  distanceKm: number | null;
  status: "APART" | "NEARBY" | "UNKNOWN";
};

const toMs = (v: string) => new Date(v).getTime();

function overlap(a: MemoryEvent, b: MemoryEvent): boolean {
  return toMs(a.startAt) <= toMs(b.endAt) && toMs(b.startAt) <= toMs(a.endAt);
}

function haversineKm(a: MemoryEvent, b: MemoryEvent): number | null {
  if (
    a.latitude == null || a.longitude == null ||
    b.latitude == null || b.longitude == null
  ) return null;

  const R = 6371;
  const dLat = (b.latitude - a.latitude) * Math.PI / 180;
  const dLon = (b.longitude - a.longitude) * Math.PI / 180;
  const lat1 = a.latitude * Math.PI / 180;
  const lat2 = b.latitude * Math.PI / 180;

  const x = Math.sin(dLat / 2) ** 2 +
    Math.sin(dLon / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);

  return 2 * R * Math.asin(Math.sqrt(x));
}

export function buildWhileAwaySegments(
  person1Events: MemoryEvent[],
  person2Events: MemoryEvent[],
  nearbyKm = 10
): AwaySegment[] {
  const result: AwaySegment[] = [];

  for (const a of person1Events) {
    for (const b of person2Events) {
      if (!overlap(a, b)) continue;

      const distanceKm = haversineKm(a, b);
      const status =
        distanceKm == null
          ? "UNKNOWN"
          : distanceKm <= nearbyKm
            ? "NEARBY"
            : "APART";

      result.push({
        startAt: new Date(Math.max(toMs(a.startAt), toMs(b.startAt))).toISOString(),
        endAt: new Date(Math.min(toMs(a.endAt), toMs(b.endAt))).toISOString(),
        person1Events: [a],
        person2Events: [b],
        distanceKm,
        status,
      });
    }
  }

  return result.sort((a, b) => toMs(a.startAt) - toMs(b.startAt));
}

export function buildWhileAwaySummary(
  person1Name: string,
  person2Name: string,
  segments: AwaySegment[]
) {
  const apart = segments.filter(s => s.status === "APART");
  const nearby = segments.filter(s => s.status === "NEARBY");

  return {
    title: "While You Were Away",
    people: [person1Name, person2Name],
    apartPeriods: apart.length,
    nearbyPeriods: nearby.length,
    totalPeriods: segments.length,
    segments,
  };
}
