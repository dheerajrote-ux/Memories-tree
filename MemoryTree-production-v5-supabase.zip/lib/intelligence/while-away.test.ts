import { describe, expect, it } from "vitest";
import { buildWhileAwaySegments } from "./while-away";

const event = (id: string, lat: number, lng: number, start: string, end: string) => ({
  id,
  ownerId: id,
  title: id,
  category: "travel",
  startAt: start,
  endAt: end,
  locationName: id,
  latitude: lat,
  longitude: lng,
  memoryCount: 1,
  confidence: 1
});

describe("buildWhileAwaySegments", () => {
  it("classifies overlapping distant events as apart", () => {
    const [segment] = buildWhileAwaySegments(
      [event("a", 25.2048, 55.2708, "2025-03-10T10:00:00Z", "2025-03-10T12:00:00Z")],
      [event("b", 18.5204, 73.8567, "2025-03-10T10:30:00Z", "2025-03-10T11:30:00Z")]
    );
    expect(segment.status).toBe("APART");
    expect(segment.distanceKm).toBeGreaterThan(1000);
  });

  it("classifies close overlapping events as nearby", () => {
    const [segment] = buildWhileAwaySegments(
      [event("a", 15.4909, 73.8278, "2025-03-20T10:00:00Z", "2025-03-20T12:00:00Z")],
      [event("b", 15.4910, 73.8279, "2025-03-20T10:30:00Z", "2025-03-20T11:30:00Z")]
    );
    expect(segment.status).toBe("NEARBY");
  });

  it("does not create a segment when time windows do not overlap", () => {
    const segments = buildWhileAwaySegments(
      [event("a", 15.4909, 73.8278, "2025-03-20T10:00:00Z", "2025-03-20T12:00:00Z")],
      [event("b", 15.4909, 73.8278, "2025-03-20T13:00:00Z", "2025-03-20T14:00:00Z")]
    );
    expect(segments).toHaveLength(0);
  });
});
