export const demoWhileAway = {
  person1Name: "Dhiraj",
  person2Name: "Shweta",
  person1Events: [
    {
      id: "d1",
      ownerId: "person-1",
      title: "Dubai Work Trip",
      category: "travel",
      startAt: "2025-03-10T06:00:00Z",
      endAt: "2025-03-15T18:00:00Z",
      locationName: "Dubai, UAE",
      latitude: 25.2048,
      longitude: 55.2708,
      memoryCount: 42,
      confidence: 0.98
    },
    {
      id: "d2",
      ownerId: "person-1",
      title: "Goa Beach Day",
      category: "travel",
      startAt: "2025-03-20T09:00:00Z",
      endAt: "2025-03-20T17:00:00Z",
      locationName: "Goa, India",
      latitude: 15.4909,
      longitude: 73.8278,
      memoryCount: 31,
      confidence: 0.96
    }
  ],
  person2Events: [
    {
      id: "s1",
      ownerId: "person-2",
      title: "Birthday Party",
      category: "celebration",
      startAt: "2025-03-14T14:00:00Z",
      endAt: "2025-03-15T18:30:00Z",
      locationName: "Pune, India",
      latitude: 18.5204,
      longitude: 73.8567,
      memoryCount: 28,
      confidence: 0.95
    },
    {
      id: "s2",
      ownerId: "person-2",
      title: "Goa Beach Day",
      category: "travel",
      startAt: "2025-03-20T09:30:00Z",
      endAt: "2025-03-20T17:15:00Z",
      locationName: "Goa, India",
      latitude: 15.4909,
      longitude: 73.8278,
      memoryCount: 38,
      confidence: 0.97
    }
  ]
};
